import { pgTable, text, serial, integer, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table with role and PIN
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"),
  pin: text("pin"),
  isLoggedIn: boolean("is_logged_in").default(false),
});

// Bank accounts linked to users
export const bankAccounts = pgTable("bank_accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  bankName: text("bank_name").notNull(),
  accountNumber: text("account_number").notNull(),
  balance: decimal("balance").notNull().default("0"),
  isActive: boolean("is_active").default(true),
});

// Orders table for tracking purchases
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  totalAmount: decimal("total_amount").notNull(),
  paymentMode: text("payment_mode").notNull(), // 'cod' or 'wallet'
  bankAccountId: integer("bank_account_id").references(() => bankAccounts.id),
  status: text("status").notNull().default("pending"), // pending, processing, shipped, delivered
  deliveryAddress: text("delivery_address").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Order items for tracking products in each order
export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").references(() => orders.id),
  productId: integer("product_id").notNull(),
  quantity: integer("quantity").notNull(),
  pricePerUnit: decimal("price_per_unit").notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
  pin: true,
});

export const insertBankAccountSchema = createInsertSchema(bankAccounts).pick({
  userId: true,
  bankName: true,
  accountNumber: true,
  balance: true,
});

export const insertOrderSchema = createInsertSchema(orders).pick({
  userId: true,
  totalAmount: true,
  paymentMode: true,
  bankAccountId: true,
  deliveryAddress: true,
});

export const insertOrderItemSchema = createInsertSchema(orderItems).pick({
  orderId: true,
  productId: true,
  quantity: true,
  pricePerUnit: true,
});

// Type exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type BankAccount = typeof bankAccounts.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type OrderItem = typeof orderItems.$inferSelect;