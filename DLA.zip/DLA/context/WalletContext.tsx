import React, { createContext, useState, useContext, ReactNode } from "react";
import { useAuth, Bank } from "./AuthContext";

interface WalletContextType {
  balance: number;
  withdraw: (amount: number, bank: Bank) => boolean;
  deposit: (amount: number) => void;
  validateBankPassword: (bank: Bank, password: string) => boolean;
  payWithWallet: (amount: number, bank: Bank) => boolean;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const { user, updateBankBalance } = useAuth();
  const [balance, setBalance] = useState(1000);

  const withdraw = (amount: number, bank: Bank) => {
    if (!user) return false;
    if (amount > bank.balance) return false;

    updateBankBalance(bank.cardNumber, bank.balance - amount);
    setBalance(prev => prev + amount);
    return true;
  };

  const deposit = (amount: number) => {
    if (amount <= 0 || amount > balance) return;
    setBalance(prev => prev - amount);
  };

  const validateBankPassword = (bank: Bank, password: string) => {
    return bank.password === password;
  };

  const payWithWallet = (amount: number, bank: Bank) => {
    if (!user) return false;
    if (amount > balance) return false;
    if (!validateBankPassword(bank, bank.password)) return false; // Added password validation

    setBalance(prev => prev - amount);
    updateBankBalance(bank.cardNumber, bank.balance + amount);
    return true;
  };


  return (
    <WalletContext.Provider value={{ balance, deposit, withdraw, validateBankPassword, payWithWallet }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error("useWallet must be used within a WalletProvider");
  }
  return context;
}