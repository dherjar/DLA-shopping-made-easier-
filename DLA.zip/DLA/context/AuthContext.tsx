
import React, { createContext, useState, useContext, ReactNode, useEffect } from "react";

interface User {
  username: string;
  isAdmin: boolean;
  banks: Bank[];
}

export interface Bank {
  name: string;
  cardNumber: string;
  balance: number;
  password: string;
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  addBank: (bank: Bank) => void;
  removeBank: (cardNumber: string) => void;
  updateBankBalance: (cardNumber: string, newBalance: number) => void;
  adminUpdateBalance: (username: string, cardNumber: string, amount: number) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Predefined users
const USERS = {
  "dheeraj123": { password: "2009", isAdmin: true, banks: [] },
  "shagun123": { password: "4444", isAdmin: false, banks: [] }
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState(() => {
    const savedUsers = localStorage.getItem('users');
    return savedUsers ? JSON.parse(savedUsers) : USERS;
  });
  
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  useEffect(() => {
    localStorage.setItem('users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('currentUser', user ? JSON.stringify(user) : '');
  }, [user]);

  const login = (username: string, password: string) => {
    if (users[username] && users[username].password === password) {
      const userData = {
        username,
        isAdmin: users[username].isAdmin,
        banks: users[username].banks || []
      };
      setUser(userData);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const addBank = (bank: Bank) => {
    if (!user) return;
    
    const updatedUser = {
      ...user,
      banks: [...user.banks, bank]
    };
    
    setUser(updatedUser);
    
    setUsers(prev => ({
      ...prev,
      [user.username]: {
        ...prev[user.username],
        banks: updatedUser.banks
      }
    }));
  };

  const removeBank = (cardNumber: string) => {
    if (!user) return;
    
    const updatedBanks = user.banks.filter(bank => bank.cardNumber !== cardNumber);
    const updatedUser = {
      ...user,
      banks: updatedBanks
    };
    
    setUser(updatedUser);
    
    setUsers(prev => ({
      ...prev,
      [user.username]: {
        ...prev[user.username],
        banks: updatedBanks
      }
    }));
  };

  const updateBankBalance = (cardNumber: string, newBalance: number) => {
    if (!user) return;
    
    const updatedBanks = user.banks.map(bank => 
      bank.cardNumber === cardNumber ? { ...bank, balance: newBalance } : bank
    );
    
    const updatedUser = {
      ...user,
      banks: updatedBanks
    };
    
    setUser(updatedUser);
    
    setUsers(prev => ({
      ...prev,
      [user.username]: {
        ...prev[user.username],
        banks: updatedBanks
      }
    }));
  };

  const adminUpdateBalance = (username: string, cardNumber: string, amount: number) => {
    if (!user?.isAdmin) return;
    
    setUsers(prev => {
      const targetUser = prev[username];
      if (!targetUser) return prev;
      
      const updatedBanks = targetUser.banks.map(bank => 
        bank.cardNumber === cardNumber ? { ...bank, balance: bank.balance + amount } : bank
      );
      
      return {
        ...prev,
        [username]: {
          ...targetUser,
          banks: updatedBanks
        }
      };
    });
    
    // Update current user if admin is updating their own banks
    if (username === user.username) {
      const updatedBanks = user.banks.map(bank => 
        bank.cardNumber === cardNumber ? { ...bank, balance: bank.balance + amount } : bank
      );
      
      setUser({
        ...user,
        banks: updatedBanks
      });
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, addBank, removeBank, updateBankBalance, adminUpdateBalance }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
