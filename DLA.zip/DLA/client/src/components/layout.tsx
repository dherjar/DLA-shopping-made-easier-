import { Link } from "wouter";
import { ShoppingCart, Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useCart } from "@/context/cart-context";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface LayoutProps {
  children: React.ReactNode;
  user?: { role: string }; // Added user prop
}

export function Layout({ children, user }: LayoutProps) {
  const { state: cart, dispatch } = useCart();
  const { toast } = useToast();

  const handleUpdateQuantity = (id: number, quantity: number) => {
    dispatch({ type: "UPDATE_QUANTITY", payload: { id, quantity } });
  };

  const handleRemoveItem = (id: number) => {
    dispatch({ type: "REMOVE_ITEM", payload: { id } });
  };

  const handleCheckout = async () => {
    try {
      // Navigate to order placement page
      window.location.href = "/place-order";
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process checkout",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <ScrollArea className="h-[calc(100vh-4rem)]">
                  <div className="flex flex-col gap-4 p-6">
                    <Link href="/">
                      <a className="text-lg font-semibold">Home</a>
                    </Link>
                    <Link href="/orders">
                      <a className="text-lg font-semibold">Orders</a>
                    </Link>
                    <Link href="/wallet">
                      <a className="text-lg font-semibold">E-Wallet</a>
                    </Link>
                  </div>
                </ScrollArea>
              </SheetContent>
            </Sheet>
            <Link href="/">
              <a className="text-2xl font-bold">Store</a>
            </Link>
            <nav className="hidden md:flex items-center gap-6">
              <Link href="/orders">
                <a className="text-sm font-medium hover:text-primary">Orders</a>
              </Link>
              <Link href="/wallet">
                <a className="text-sm font-medium hover:text-primary">E-Wallet</a>
              </Link>
              {user?.role === "admin" && (
                <Link href="/admin">
                  <a className="text-sm font-medium hover:text-primary">Admin Dashboard</a>
                </Link>
              )}
            </nav>
          </div>
          <div className="flex items-center gap-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="relative">
                  <ShoppingCart className="h-6 w-6" />
                  {cart.items.length > 0 && (
                    <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground rounded-full w-5 h-5 text-xs flex items-center justify-center">
                      {cart.items.length}
                    </span>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="h-full flex flex-col">
                  <h2 className="text-lg font-semibold mb-4">Shopping Cart</h2>
                  <ScrollArea className="flex-1">
                    {cart.items.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        Your cart is empty
                      </p>
                    ) : (
                      <div className="space-y-4">
                        {cart.items.map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center justify-between gap-4 border-b pb-4"
                          >
                            <div>
                              <h3 className="font-medium">{item.name}</h3>
                              <p className="text-sm text-muted-foreground">
                                {item.brand}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() =>
                                  handleUpdateQuantity(
                                    item.id,
                                    Math.max(0, item.quantity - 1)
                                  )
                                }
                              >
                                -
                              </Button>
                              <span>{item.quantity}</span>
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() =>
                                  handleUpdateQuantity(item.id, item.quantity + 1)
                                }
                              >
                                +
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleRemoveItem(item.id)}
                              >
                                ×
                              </Button>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">
                                {item.price * item.quantity} ores
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                  {cart.items.length > 0 && (
                    <div className="border-t pt-4 mt-4">
                      <div className="flex items-center justify-between mb-4">
                        <span className="font-semibold">Total:</span>
                        <span className="font-semibold">{cart.total} ores</span>
                      </div>
                      <Button className="w-full" onClick={handleCheckout}>
                        Proceed to Checkout
                      </Button>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>
      <main className="flex-1">{children}</main>
      <footer className="border-t py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          © 2024 Store. All rights reserved.
        </div>
      </footer>
    </div>
  );
}