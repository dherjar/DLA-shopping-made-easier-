import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Layout } from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

type BankAccount = {
  id: number;
  userId: number;
  bankName: string;
  accountNumber: string;
  balance: string;
};

type Order = {
  id: number;
  userId: number;
  totalAmount: string;
  paymentMode: string;
  status: string;
  deliveryAddress: string;
  createdAt: string;
};

export default function AdminDashboard() {
  const { toast } = useToast();
  const [newBalance, setNewBalance] = useState("");
  const [selectedBankId, setSelectedBankId] = useState<number | null>(null);

  // Fetch all bank accounts
  const { data: bankAccounts } = useQuery<BankAccount[]>({
    queryKey: ["/api/admin/bank-accounts"],
  });

  // Fetch all orders
  const { data: orders } = useQuery<Order[]>({
    queryKey: ["/api/admin/orders"],
  });

  // Update bank balance mutation
  const updateBalanceMutation = useMutation({
    mutationFn: async ({ bankId, balance }: { bankId: number; balance: number }) => {
      await fetch(`/api/admin/bank-accounts/${bankId}/balance`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ balance }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/bank-accounts"] });
      toast({
        title: "Success",
        description: "Bank balance updated successfully",
      });
      setNewBalance("");
      setSelectedBankId(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update bank balance",
        variant: "destructive",
      });
    },
  });

  // Update order status mutation
  const updateOrderStatusMutation = useMutation({
    mutationFn: async ({ orderId, status }: { orderId: number; status: string }) => {
      await fetch(`/api/admin/orders/${orderId}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
      toast({
        title: "Success",
        description: "Order status updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update order status",
        variant: "destructive",
      });
    },
  });

  const handleUpdateBalance = (bankId: number) => {
    const balance = parseFloat(newBalance);
    if (isNaN(balance) || balance < 0) {
      toast({
        title: "Error",
        description: "Please enter a valid balance",
        variant: "destructive",
      });
      return;
    }
    updateBalanceMutation.mutate({ bankId, balance });
  };

  const handleUpdateOrderStatus = (orderId: number, newStatus: string) => {
    updateOrderStatusMutation.mutate({ orderId, status: newStatus });
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          Admin Dashboard
        </h1>

        {/* Bank Accounts Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Bank Accounts</h2>
          <div className="grid gap-6">
            {bankAccounts?.map((account) => (
              <Card key={account.id}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="font-medium">{account.bankName}</h3>
                      <p className="text-sm text-muted-foreground">
                        Account: {account.accountNumber}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Current Balance: {account.balance} ores
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        placeholder="New Balance"
                        className="w-32"
                        value={selectedBankId === account.id ? newBalance : ""}
                        onChange={(e) => {
                          setSelectedBankId(account.id);
                          setNewBalance(e.target.value);
                        }}
                      />
                      <Button
                        onClick={() => handleUpdateBalance(account.id)}
                        disabled={selectedBankId !== account.id || !newBalance}
                      >
                        Update
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Orders Section */}
        <section>
          <h2 className="text-2xl font-semibold mb-4">Orders</h2>
          <div className="grid gap-6">
            {orders?.map((order) => (
              <Card key={order.id}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold">Order #{order.id}</h3>
                      <p className="text-sm text-muted-foreground">
                        {new Date(order.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">{order.totalAmount} ores</p>
                      <p className="text-sm text-muted-foreground">
                        {order.paymentMode === 'cod' ? 'Cash on Delivery' : 'E-wallet'}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <p>
                      <span className="font-medium">Status: </span>
                      <span className="capitalize">{order.status}</span>
                    </p>
                    <p>
                      <span className="font-medium">Delivery Address: </span>
                      {order.deliveryAddress}
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      onClick={() => handleUpdateOrderStatus(order.id, 'processing')}
                      disabled={order.status !== 'pending'}
                    >
                      Mark Processing
                    </Button>
                    <Button
                      onClick={() => handleUpdateOrderStatus(order.id, 'shipped')}
                      disabled={order.status !== 'processing'}
                    >
                      Mark Shipped
                    </Button>
                    <Button
                      onClick={() => handleUpdateOrderStatus(order.id, 'delivered')}
                      disabled={order.status !== 'shipped'}
                    >
                      Mark Delivered
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </Layout>
  );
}
