import React from "react";
import { useQuery } from "react-query";
import { useToast } from "../context/ToastContext";

type Order = {
  id: number;
  totalAmount: string;
  paymentMode: string;
  status: string;
  deliveryAddress: string;
  createdAt: string;
};

export default function Orders() {
  const { toast } = useToast();
  const { data: orders } = useQuery<Order[]>({ queryKey: ["/api/orders"] });

  const displayOrders = orders || [];

  return (
    <div>
      <h1>My Orders</h1>
      {displayOrders.length === 0 ? (
        <p>No orders found</p>
      ) : (
        displayOrders.map((order) => (
          <div key={order.id}>
            <h3>Order #{order.id}</h3>
            <p>Total Amount: {order.totalAmount}</p>
            <p>Payment Mode: {order.paymentMode}</p>
            <p>Status: {order.status}</p>
            <p>Delivery Address: {order.deliveryAddress}</p>
          </div>
        ))
      )}
    </div>
  );
}import React, { useState } from "react";
import { useLocation } from "react-router-dom"; // Assuming you're using react-router
import { useCart } from "../context/CartContext";
import { useToast } from "../context/ToastContext"; // A context for displaying messages
import { useQuery, useMutation } from "react-query";

type BankAccount = {
  id: number;
  bankName: string;
  accountNumber: string;
  balance: string;
};

export default function PlaceOrder() {
  const [, setLocation] = useLocation();
  const { state: cart, dispatch } = useCart();
  const { toast } = useToast();
  
  const [paymentMode, setPaymentMode] = useState<"cod" | "wallet">("cod");
  const [selectedBank, setSelectedBank] = useState<number | null>(null);
  const [pin, setPin] = useState("");
  const [address, setAddress] = useState("");

  // Fetch user's bank accounts
  const { data: bankAccounts } = useQuery<BankAccount[]>({
    queryKey: ["/api/bank-accounts"],
    enabled: paymentMode === "wallet",
  });

  // Place order mutation
  const placeOrderMutation = useMutation({
    mutationFn: async () => {
      if (!address) {
        throw new Error("Please enter delivery address");
      }

      if (paymentMode === "wallet") {
        if (!selectedBank) {
          throw new Error("Please select a bank account");
        }
        if (!pin || pin.length !== 4) {
          throw new Error("Please enter your 4-digit PIN");
        }
      }

      const orderData = {
        items: cart.items.map((item) => ({
          productId: item.id,
          quantity: item.quantity,
          pricePerUnit: item.price,
        })),
        totalAmount: cart.total,
        paymentMode,
        bankAccountId: paymentMode === "wallet" ? selectedBank : null,
        pin: paymentMode === "wallet" ? pin : null,
        deliveryAddress: address,
      };

      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderData),
      });
      if (!res.ok) throw new Error("Failed to place order");
      return res.json();
    },
    onSuccess: () => {
      dispatch({ type: "CLEAR_CART" });
      toast({ title: "Success", description: "Order placed successfully" });
      setLocation("/orders");
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  if (cart.items.length === 0) {
    return <div>Your cart is empty. Please add some items before checking out.</div>;
  }

  return (
    <div>
      <h1>Place Order</h1>
      <div>
        <h3>Payment Mode</h3>
        <button onClick={() => setPaymentMode("cod")}>Cash on Delivery</button>
        <button onClick={() => setPaymentMode("wallet")}>E-Wallet</button>
      </div>

      {paymentMode === "wallet" && (
        <div>
          <select onChange={(e) => setSelectedBank(Number(e.target.value))}>
            {bankAccounts.map((bank) => (
              <option key={bank.id} value={bank.id}>
                {bank.bankName} - {bank.accountNumber} (Balance: {bank.balance})
              </option>
            ))}
          </select>
          <input type="password" placeholder="Enter your 4 digit PIN" value={pin} onChange={(e) => setPin(e.target.value)} />
        </div>
      )}

      <div>
        <h3>Delivery Address</h3>
        <input type="text" placeholder="Enter your delivery address" value={address} onChange={(e) => setAddress(e.target.value)} />
      </div>

      <button onClick={() => placeOrderMutation.mutate()}>Place Order</button>
    </div>
  );
}const updateOrderStatus = async (orderId: number, status: string) => {
  try {
    await fetch(`/api/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    toast({
      title: "Success",
      description: "Order status updated successfully"
    });
  } catch (error) {
    toast({
      title: "Error",
      description: "Failed to update order status",
      variant: "destructive"
    });
  }
};

// Inside the orders display map
<Button onClick={() => updateOrderStatus(order.id, 'processing')} disabled={order.status !== 'pending'}>
    Mark Processing
</Button>import { useState } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/cart-context";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

type BankAccount = {
  id: number;
  bankName: string;
  accountNumber: string;
  balance: string;
};

export default function PlaceOrder() {
  const [, setLocation] = useLocation();
  const { state: cart, dispatch } = useCart();
  const { toast } = useToast();
  const [paymentMode, setPaymentMode] = useState<"cod" | "wallet">("cod");
  const [selectedBank, setSelectedBank] = useState<number | null>(null);
  const [pin, setPin] = useState("");
  const [address, setAddress] = useState("");

  // Fetch user's bank accounts
  const { data: bankAccounts } = useQuery<BankAccount[]>({
    queryKey: ["/api/bank-accounts"],
    enabled: paymentMode === "wallet",
  });

  // Place order mutation
  const placeOrderMutation = useMutation({
    mutationFn: async () => {
      if (!address) {
        throw new Error("Please enter delivery address");
      }

      if (paymentMode === "wallet") {
        if (!selectedBank) {
          throw new Error("Please select a bank account");
        }
        if (!pin || pin.length !== 4) {
          throw new Error("Please enter your 4-digit PIN");
        }
      }

      const orderData = {
        items: cart.items.map((item) => ({
          productId: item.id,
          quantity: item.quantity,
          pricePerUnit: item.price,
        })),
        totalAmount: cart.total,
        paymentMode,
        bankAccountId: paymentMode === "wallet" ? selectedBank : null,
        pin: paymentMode === "wallet" ? pin : null,
        deliveryAddress: address,
      };

      const res = await apiRequest("POST", "/api/orders", orderData);
      if (!res.ok) throw new Error("Failed to place order");
      return res.json();
    },
    onSuccess: () => {
      dispatch({ type: "CLEAR_CART" });
      toast({
        title: "Success",
        description: "Order placed successfully",
      });
      setLocation("/orders");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (cart.items.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            Place Order
          </h1>
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground">
                Your cart is empty. Please add some items before checking out.
              </p>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          Place Order
        </h1>

        <div className="grid gap-8 md:grid-cols-2">
          <div>
            <Card>
              <CardContent className="p-6">
                <h2 className="text-2xl font-semibold mb-4">Order Summary</h2>
                <div className="space-y-4">
                  {cart.items.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between gap-4"
                    >
                      <div>
                        <h3 className="font-medium">{item.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          Quantity: {item.quantity}
                        </p>
                      </div>
                      <p className="font-medium">{item.price * item.quantity} ores</p>
                    </div>
                  ))}
                  <div className="border-t pt-4">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">Total:</span>
                      <span className="font-semibold">{cart.total} ores</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardContent className="p-6 space-y-6">
                <h2 className="text-2xl font-semibold mb-4">Payment Details</h2>

                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Payment Mode</h3>
                    <div className="flex gap-4">
                      <Button
                        variant={paymentMode === "cod" ? "default" : "outline"}
                        onClick={() => setPaymentMode("cod")}
                      >
                        Cash on Delivery
                      </Button>
                      <Button
                        variant={paymentMode === "wallet" ? "default" : "outline"}
                        onClick={() => setPaymentMode("wallet")}
                      >
                        E-Wallet
                      </Button>
                    </div>
                  </div>

                  {paymentMode === "wallet" && (
                    <>
                      <div>
                        <h3 className="font-medium mb-2">Select Bank Account</h3>
                        <div className="space-y-2">
                          {bankAccounts?.map((account) => (
                            <Button
                              key={account.id}
                              variant={
                                selectedBank === account.id ? "default" : "outline"
                              }
                              className="w-full justify-between"
                              onClick={() => setSelectedBank(account.id)}
                            >
                              <span>{account.bankName}</span>
                              <span>{account.balance} ores</span>
                            </Button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="font-medium mb-2">Enter PIN</h3>
                        <Input
                          type="password"
                          maxLength={4}
                          placeholder="Enter 4-digit PIN"
                          value={pin}
                          onChange={(e) => setPin(e.target.value)}
                        />
                      </div>
                    </>
                  )}

                  <div>
                    <h3 className="font-medium mb-2">Delivery Address</h3>
                    <Input
                      placeholder="Enter your delivery address"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                    />
                  </div>

                  <Button
                    className="w-full"
                    onClick={() => placeOrderMutation.mutate()}
                    disabled={placeOrderMutation.isPending}
                  >
                    Place Order
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
