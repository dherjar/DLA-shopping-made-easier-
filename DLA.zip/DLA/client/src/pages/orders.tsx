import { useQuery } from "@tanstack/react-query";
import { Layout } from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";

type Order = {
  id: number;
  totalAmount: string;
  paymentMode: string;
  status: string;
  deliveryAddress: string;
  createdAt: string;
  items?: Array<{
    productId: number;
    quantity: number;
    pricePerUnit: string;
  }>;
};

export default function Orders() {
  const { toast } = useToast();
  const { data: orders } = useQuery<Order[]>({ 
    queryKey: ["/api/orders"]
  });

  const { data: adminOrders } = useQuery<Order[]>({
    queryKey: ["/api/admin/orders"],
    enabled: false // Only fetch for admin users
  });

  const updateOrderStatus = async (orderId: number, status: string) => {
    try {
      await fetch(`/api/admin/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      toast({
        title: "Success",
        description: "Order status updated successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update order status",
        variant: "destructive"
      });
    }
  };

  const displayOrders = orders || [];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          My Orders
        </h1>

        <div className="space-y-6">
          {displayOrders.map((order) => (
            <Card key={order.id}>
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold">Order #{order.id}</h3>
                    <p className="text-sm text-muted-foreground">
                      {new Date(order.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{order.totalAmount} ores</p>
                    <p className="text-sm text-muted-foreground">
                      {order.paymentMode === 'cod' ? 'Cash on Delivery' : 'E-wallet'}
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <p>
                    <span className="font-medium">Status: </span>
                    <span className="capitalize">{order.status}</span>
                  </p>
                  <p>
                    <span className="font-medium">Delivery Address: </span>
                    {order.deliveryAddress}
                  </p>
                </div>

                {adminOrders && (
                  <div className="mt-4 flex gap-2">
                    <Button 
                      onClick={() => updateOrderStatus(order.id, 'processing')}
                      disabled={order.status !== 'pending'}
                    >
                      Mark Processing
                    </Button>
                    <Button
                      onClick={() => updateOrderStatus(order.id, 'shipped')}
                      disabled={order.status !== 'processing'}
                    >
                      Mark Shipped
                    </Button>
                    <Button
                      onClick={() => updateOrderStatus(order.id, 'delivered')}
                      disabled={order.status !== 'shipped'}
                    >
                      Mark Delivered
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}

          {displayOrders.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No orders found</p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
