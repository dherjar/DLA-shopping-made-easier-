import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Layout } from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

type BankAccount = {
  id: number;
  bankName: string;
  accountNumber: string;
  balance: string;
  isActive: boolean;
};

export default function Wallet() {
  const { toast } = useToast();
  const [bankName, setBankName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [pin, setPin] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [selectedBank, setSelectedBank] = useState<number | null>(null);

  const { data: bankAccounts } = useQuery<BankAccount[]>({
    queryKey: ["/api/bank-accounts"],
  });

  const addBankMutation = useMutation({
    mutationFn: async (data: { bankName: string; accountNumber: string }) => {
      const res = await fetch("/api/bank-accounts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to add bank account");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bank-accounts"] });
      setBankName("");
      setAccountNumber("");
      toast({
        title: "Success",
        description: "Bank account added successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add bank account",
        variant: "destructive",
      });
    },
  });

  const setPinMutation = useMutation({
    mutationFn: async (pin: string) => {
      const res = await fetch("/api/users/pin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pin }),
      });
      if (!res.ok) throw new Error("Failed to set PIN");
      return res.json();
    },
    onSuccess: () => {
      setPin("");
      toast({
        title: "Success",
        description: "PIN set successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to set PIN",
        variant: "destructive",
      });
    },
  });

  const handleAddBank = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bankName || !accountNumber) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }
    addBankMutation.mutate({ bankName, accountNumber });
  };

  const handleSetPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pin || pin.length !== 4 || !/^\d+$/.test(pin)) {
      toast({
        title: "Error",
        description: "PIN must be exactly 4 digits",
        variant: "destructive",
      });
      return;
    }
    setPinMutation.mutate(pin);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          E-Wallet
        </h1>

        {/* PIN Setup Section */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-4">Set Transaction PIN</h2>
            <form onSubmit={handleSetPin} className="flex gap-4">
              <Input
                type="password"
                placeholder="Enter 4-digit PIN"
                maxLength={4}
                value={pin}
                onChange={(e) => setPin(e.target.value)}
              />
              <Button type="submit">Set PIN</Button>
            </form>
          </CardContent>
        </Card>

        {/* Add Bank Account Section */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-4">Add Bank Account</h2>
            <form onSubmit={handleAddBank} className="space-y-4">
              <div>
                <Input
                  placeholder="Bank Name"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                />
              </div>
              <div>
                <Input
                  placeholder="Account Number"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                />
              </div>
              <Button type="submit">Add Bank Account</Button>
            </form>
          </CardContent>
        </Card>

        {/* Bank Accounts List */}
        <h2 className="text-2xl font-semibold mb-4">Your Bank Accounts</h2>
        <div className="grid gap-6">
          {bankAccounts?.map((account) => (
            <Card key={account.id}>
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold">{account.bankName}</h3>
                    <p className="text-sm text-muted-foreground">
                      Account: {account.accountNumber}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold">{account.balance} ores</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {(!bankAccounts || bankAccounts.length === 0) && (
            <p className="text-center text-muted-foreground py-8">
              No bank accounts added yet
            </p>
          )}
        </div>
      </div>
    </Layout>
  );
}
