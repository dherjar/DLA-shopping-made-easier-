import { Card, CardContent } from "@/components/ui/card";
import { Layout } from "@/components/layout";
import { useCart } from "@/context/cart-context";

const products = [
  {
    id: 1,
    name: "iPhone 15 Pro Max",
    brand: "Apple",
    description: "A17 Pro chip, 48MP camera, 6.7\" Super Retina XDR display",
    price: 1499, // Price in ores (149,900 INR)
    image: "https://placehold.co/400x400?text=iPhone+15+Pro+Max"
  },
  {
    id: 2,
    name: "Samsung Galaxy S24 Ultra",
    brand: "Samsung",
    description: "Snapdragon 8 Gen 3, 200MP camera, 6.8\" Dynamic AMOLED",
    price: 1349, // Price in ores (134,900 INR)
    image: "https://placehold.co/400x400?text=Samsung+S24+Ultra"
  },
  {
    id: 3,
    name: "MacBook Pro 16\"",
    brand: "Apple",
    description: "M3 Max chip, 32GB RAM, 1TB SSD, Liquid Retina XDR display",
    price: 2499, // Price in ores (249,900 INR)
    image: "https://placehold.co/400x400?text=MacBook+Pro"
  },
  {
    id: 4,
    name: "Sony WH-1000XM5",
    brand: "Sony",
    description: "Wireless noise cancelling headphones with 30h battery life",
    price: 399, // Price in ores (39,900 INR)
    image: "https://placehold.co/400x400?text=Sony+WH-1000XM5"
  },
  {
    id: 5,
    name: "iPad Pro 12.9\"",
    brand: "Apple",
    description: "M2 chip, Liquid Retina XDR display, 256GB storage",
    price: 1199, // Price in ores (119,900 INR)
    image: "https://placehold.co/400x400?text=iPad+Pro"
  },
  {
    id: 6,
    name: "Nothing Phone (2)",
    brand: "Nothing",
    description: "Snapdragon 8+ Gen 1, Glyph interface, 50MP dual camera",
    price: 699, // Price in ores (69,900 INR)
    image: "https://placehold.co/400x400?text=Nothing+Phone"
  }
];

export default function Home() {
  const { dispatch } = useCart();

  const handleAddToCart = (product: typeof products[0]) => {
    dispatch({
      type: "ADD_ITEM",
      payload: {
        id: product.id,
        name: product.name,
        brand: product.brand,
        price: product.price,
        quantity: 1
      }
    });
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          Latest Electronics
        </h1>
        <p className="text-muted-foreground mb-8">Prices in ores (1 ore = 100 INR)</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardContent className="p-4">
                <div className="aspect-square w-full bg-muted mb-4 rounded-lg overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src = "https://placehold.co/400x400?text=Product+Image";
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">{product.name}</h3>
                    <span className="text-sm text-muted-foreground">{product.brand}</span>
                  </div>
                  <p className="text-muted-foreground text-sm">{product.description}</p>
                  <div className="flex items-center justify-between pt-2">
                    <span className="text-lg font-bold">{product.price} ores</span>
                    <button
                      onClick={() => handleAddToCart(product)}
                      className="bg-primary text-primary-foreground px-4 py-2 rounded-md hover:bg-primary/90 transition-colors"
                    >
                      Add to Cart
                    </button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}