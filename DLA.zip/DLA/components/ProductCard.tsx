
import React from "react";
import { useCart } from "../context/CartContext";

interface Product {
  name: string;
  brand: string;
  priceINR: number;
  priceOre: number;
  image: string;
  description: string;
}

export default function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart();
  
  const handleAddToCart = () => {
    addToCart({
      id: `${product.brand}-${product.name}`,
      name: `${product.brand} ${product.name}`,
      priceOre: product.priceOre
    });
    alert(`${product.brand} ${product.name} added to cart!`);
  };

  return (
    <div style={{ 
      border: "1px solid #ddd", 
      borderRadius: "8px",
      padding: "20px", 
      width: "300px",
      boxShadow: "0 2px 4px rgba(0,0,0,0.1)"
    }}>
      <img 
        src={product.image} 
        alt={product.name} 
        style={{ 
          width: "100%", 
          height: "200px", 
          objectFit: "contain",
          marginBottom: "15px"
        }} 
      />
      <h2 style={{ marginBottom: "10px" }}>{product.brand} {product.name}</h2>
      <p style={{ color: "#666", marginBottom: "15px" }}>{product.description}</p>
      <div style={{ marginBottom: "15px" }}>
        <p><strong>Price:</strong> {product.priceOre.toFixed(2)} Ores ({product.priceINR.toLocaleString()} INR)</p>
        <p style={{ fontSize: "12px", color: "#888" }}>1 Ore = 100 INR</p>
      </div>
      <button 
        onClick={handleAddToCart}
        style={{ 
          padding: "10px 15px", 
          backgroundColor: "#4CAF50", 
          color: "white", 
          border: "none", 
          borderRadius: "4px", 
          cursor: "pointer",
          width: "100%" 
        }}
      >
        Add to Cart
      </button>
    </div>
  );
}
