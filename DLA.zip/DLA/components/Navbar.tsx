
import React from "react";
import Link from "next/link";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { cart } = useCart();
  const { user, logout } = useAuth();

  return (
    <nav style={{ 
      display: "flex", 
      justifyContent: "space-between", 
      padding: "1rem", 
      backgroundColor: "#f0f0f0", 
      marginBottom: "1rem" 
    }}>
      <div>
        <Link href="/" style={{ marginRight: "1rem" }}>Home</Link>
        <Link href="/cart" style={{ marginRight: "1rem" }}>Cart ({cart.length})</Link>
        <Link href="/account" style={{ marginRight: "1rem" }}>Account</Link>
        {user && <Link href="/orders" style={{ marginRight: "1rem" }}>Orders</Link>}
        {user?.isAdmin && <Link href="/admin" style={{ marginRight: "1rem" }}>Admin</Link>}
      </div>
      <div style={{ display: "flex", alignItems: "center" }}>
        {user ? (
          <>
            <span style={{ marginRight: "1rem" }}>Hello, {user.username}</span>
            <button 
              onClick={logout}
              style={{ 
                padding: "5px 10px", 
                backgroundColor: "#f44336", 
                color: "white", 
                border: "none", 
                borderRadius: "4px", 
                cursor: "pointer" 
              }}
            >
              Logout
            </button>
          </>
        ) : (
          <Link href="/login">Login</Link>
        )}
      </div>
    </nav>
  );
}
