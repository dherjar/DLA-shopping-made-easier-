
import React, { useState } from "react";
import { useRouter } from "next/router";
import Navbar from "../components/Navbar";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";
import { useWallet } from "../context/WalletContext";
import { useOrders } from "../context/OrderContext";

export default function Cart() {
  const { cart, clearCart, getTotal } = useCart();
  const { user } = useAuth();
  const { addOrder } = useOrders();
  const { balance, validateBankPassword, payWithWallet } = useWallet();
  const total = getTotal();
  const router = useRouter();
  
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState<"cod" | "ewallet">("cod");
  const [selectedBank, setSelectedBank] = useState("");
  const [bankPassword, setBankPassword] = useState("");
  const [address, setAddress] = useState("");
  const [error, setError] = useState("");
  
  React.useEffect(() => {
    if (!user) {
      router.push("/login");
    }
  }, [user, router]);
  
  if (!user) {
    return <div>Redirecting to login...</div>;
  }
  
  const handleCheckout = () => {
    if (cart.length === 0) {
      setError("Your cart is empty!");
      return;
    }
    
    setStep(2);
  };
  
  const handlePaymentSubmit = () => {
    setError("");
    
    if (paymentMethod === "ewallet") {
      if (!selectedBank) {
        setError("Please select a bank account!");
        return;
      }
      
      if (!bankPassword) {
        setError("Please enter your bank password!");
        return;
      }
      
      const bank = user.banks.find(b => b.cardNumber === selectedBank);
      
      if (!bank) {
        setError("Bank not found!");
        return;
      }
      
      if (!validateBankPassword(bank, bankPassword)) {
        setError("Invalid bank password!");
        return;
      }
      
      if (bank.balance < total) {
        setError("Insufficient funds in selected bank!");
        return;
      }
      
      const success = payWithWallet(total, bank);
      
      if (!success) {
        setError("Payment failed. Please try again.");
        return;
      }
    }
    
    setStep(3);
  };
  
  const handlePlaceOrder = () => {
    if (!address) {
      setError("Please enter a delivery address!");
      return;
    }
    
    const orderItems = cart.map(item => ({
      productId: item.id,
      name: item.name,
      price: item.priceOre,
      quantity: item.quantity
    }));
    
    const order = {
      userId: user.username,
      items: orderItems,
      totalAmount: total,
      paymentMethod: paymentMethod,
      bankCardNumber: paymentMethod === "ewallet" ? selectedBank : undefined,
      address: address
    };
    
    addOrder(order);
    clearCart();
    router.push("/orders");
  };
  
  // Cart view
  if (step === 1) {
    return (
      <div>
        <Navbar />
        <div style={{ padding: "0 20px", maxWidth: "800px", margin: "0 auto" }}>
          <h1>Your Cart</h1>
          {error && <p style={{ color: "red" }}>{error}</p>}
          
          {cart.length === 0 ? (
            <div>
              <p>Your cart is empty.</p>
              <button
                onClick={() => router.push("/")}
                style={{ 
                  padding: "10px 15px", 
                  backgroundColor: "#4CAF50", 
                  color: "white", 
                  border: "none", 
                  borderRadius: "4px", 
                  cursor: "pointer" 
                }}
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            <>
              <div style={{ 
                display: "grid", 
                gap: "15px",
                marginBottom: "30px"
              }}>
                {cart.map((item, index) => (
                  <div key={index} style={{ 
                    border: "1px solid #ddd", 
                    borderRadius: "8px", 
                    padding: "15px",
                    display: "flex",
                    justifyContent: "space-between"
                  }}>
                    <div>
                      <h3>{item.name}</h3>
                      <p>{item.priceOre.toFixed(2)} Ores</p>
                    </div>
                  </div>
                ))}
              </div>
              
              <div style={{ 
                marginTop: "20px", 
                marginBottom: "30px", 
                padding: "15px", 
                backgroundColor: "#f5f5f5", 
                borderRadius: "8px" 
              }}>
                <h2>Total: {total.toFixed(2)} Ores</h2>
              </div>
              
              <div>
                <button 
                  onClick={handleCheckout}
                  style={{ 
                    padding: "10px 20px", 
                    backgroundColor: "#4CAF50", 
                    color: "white", 
                    border: "none", 
                    borderRadius: "5px", 
                    cursor: "pointer" 
                  }}
                >
                  Proceed to Checkout
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }
  
  // Payment method selection
  if (step === 2) {
    return (
      <div>
        <Navbar />
        <div style={{ padding: "0 20px", maxWidth: "600px", margin: "0 auto" }}>
          <h1>Payment Method</h1>
          {error && <p style={{ color: "red" }}>{error}</p>}
          
          <div style={{ marginBottom: "20px" }}>
            <div style={{ marginBottom: "10px" }}>
              <label>
                <input 
                  type="radio" 
                  checked={paymentMethod === "cod"} 
                  onChange={() => setPaymentMethod("cod")} 
                /> 
                Cash on Delivery
              </label>
            </div>
            <div>
              <label>
                <input 
                  type="radio" 
                  checked={paymentMethod === "ewallet"} 
                  onChange={() => setPaymentMethod("ewallet")} 
                /> 
                E-Wallet
              </label>
            </div>
          </div>
          
          {paymentMethod === "ewallet" && (
            <div style={{ marginTop: "20px" }}>
              <h3>Select Bank</h3>
              {user?.banks.length === 0 ? (
                <p>You have no bank accounts. Please add one in your account page.</p>
              ) : (
                <>
                  <div style={{ marginBottom: "15px" }}>
                    <select
                      value={selectedBank} 
                      onChange={(e) => setSelectedBank(e.target.value)}
                      style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
                    >
                      <option value="">Select a bank</option>
                      {user?.banks.map(bank => (
                        <option key={bank.cardNumber} value={bank.cardNumber}>
                          {bank.name} - {bank.cardNumber} (Balance: {bank.balance.toFixed(2)} Ores)
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  {selectedBank && (
                    <div style={{ marginBottom: "15px" }}>
                      <label style={{ display: "block", marginBottom: "5px" }}>Bank Password</label>
                      <input
                        type="password"
                        value={bankPassword}
                        onChange={(e) => setBankPassword(e.target.value)}
                        style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
                      />
                    </div>
                  )}
                </>
              )}
            </div>
          )}
          
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: "30px" }}>
            <button 
              onClick={() => setStep(1)}
              style={{ 
                padding: "10px 20px", 
                backgroundColor: "#f44336", 
                color: "white", 
                border: "none", 
                borderRadius: "5px", 
                cursor: "pointer" 
              }}
            >
              Back to Cart
            </button>
            <button 
              onClick={handlePaymentSubmit}
              style={{ 
                padding: "10px 20px", 
                backgroundColor: "#4CAF50", 
                color: "white", 
                border: "none", 
                borderRadius: "5px", 
                cursor: "pointer" 
              }}
            >
              Continue
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  // Address input
  if (step === 3) {
    return (
      <div>
        <Navbar />
        <div style={{ padding: "0 20px", maxWidth: "600px", margin: "0 auto" }}>
          <h1>Delivery Address</h1>
          {error && <p style={{ color: "red" }}>{error}</p>}
          
          <div style={{ marginBottom: "20px" }}>
            <label style={{ display: "block", marginBottom: "5px" }}>Enter your delivery address</label>
            <textarea
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              style={{ 
                width: "100%", 
                padding: "8px", 
                borderRadius: "4px", 
                border: "1px solid #ddd",
                minHeight: "100px" 
              }}
            />
          </div>
          
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <button 
              onClick={() => setStep(2)}
              style={{ 
                padding: "10px 20px", 
                backgroundColor: "#f44336", 
                color: "white", 
                border: "none", 
                borderRadius: "5px", 
                cursor: "pointer" 
              }}
            >
              Back
            </button>
            <button 
              onClick={handlePlaceOrder}
              style={{ 
                padding: "10px 20px", 
                backgroundColor: "#4CAF50", 
                color: "white", 
                border: "none", 
                borderRadius: "5px", 
                cursor: "pointer" 
              }}
            >
              Place Order
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  return null;
}
