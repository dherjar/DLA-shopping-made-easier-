
import React from "react";
import { useRouter } from "next/router";
import Navbar from "../components/Navbar";
import { useAuth } from "../context/AuthContext";
import { useOrders } from "../context/OrderContext";

export default function Orders() {
  const { user } = useAuth();
  const { getUserOrders } = useOrders();
  const router = useRouter();
  
  React.useEffect(() => {
    if (!user) {
      router.push("/login");
    }
  }, [user, router]);
  
  if (!user) {
    return <div>Redirecting to login...</div>;
  }
  
  const userOrders = getUserOrders(user.username);
  
  return (
    <div>
      <Navbar />
      <div style={{ padding: "0 20px", maxWidth: "1000px", margin: "0 auto" }}>
        <h1>Your Orders</h1>
        
        {userOrders.length === 0 ? (
          <p>You have no orders yet.</p>
        ) : (
          <div>
            {userOrders.map(order => (
              <div key={order.id} style={{ 
                border: "1px solid #ddd", 
                borderRadius: "8px", 
                padding: "20px", 
                marginBottom: "20px"
              }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "15px" }}>
                  <div>
                    <h3>Order #{order.id}</h3>
                    <p>Date: {new Date(order.date).toLocaleString()}</p>
                  </div>
                  <div>
                    <span style={{ 
                      padding: "5px 10px", 
                      borderRadius: "4px", 
                      backgroundColor: 
                        order.status === "pending" ? "#FFC107" :
                        order.status === "processing" ? "#2196F3" :
                        order.status === "shipped" ? "#9C27B0" :
                        order.status === "delivered" ? "#4CAF50" :
                        "#F44336",
                      color: "white"
                    }}>
                      {order.status.toUpperCase()}
                    </span>
                  </div>
                </div>
                
                <div style={{ marginBottom: "20px" }}>
                  <h4>Items</h4>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                      <tr>
                        <th style={{ textAlign: "left", padding: "8px 0", borderBottom: "1px solid #ddd" }}>Product</th>
                        <th style={{ textAlign: "right", padding: "8px 0", borderBottom: "1px solid #ddd" }}>Price</th>
                        <th style={{ textAlign: "right", padding: "8px 0", borderBottom: "1px solid #ddd" }}>Quantity</th>
                        <th style={{ textAlign: "right", padding: "8px 0", borderBottom: "1px solid #ddd" }}>Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {order.items.map((item, index) => (
                        <tr key={index}>
                          <td style={{ padding: "8px 0", borderBottom: "1px solid #eee" }}>{item.name}</td>
                          <td style={{ textAlign: "right", padding: "8px 0", borderBottom: "1px solid #eee" }}>
                            {item.price.toFixed(2)} Ores
                          </td>
                          <td style={{ textAlign: "right", padding: "8px 0", borderBottom: "1px solid #eee" }}>
                            {item.quantity}
                          </td>
                          <td style={{ textAlign: "right", padding: "8px 0", borderBottom: "1px solid #eee" }}>
                            {(item.price * item.quantity).toFixed(2)} Ores
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr>
                        <td colSpan={3} style={{ textAlign: "right", padding: "15px 0", fontWeight: "bold" }}>Total</td>
                        <td style={{ textAlign: "right", padding: "15px 0", fontWeight: "bold" }}>
                          {order.totalAmount.toFixed(2)} Ores
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
                
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <div>
                    <p><strong>Payment Method:</strong> {order.paymentMethod === "ewallet" ? "E-Wallet" : "Cash on Delivery"}</p>
                    {order.bankCardNumber && (
                      <p><strong>Bank Card:</strong> {order.bankCardNumber}</p>
                    )}
                  </div>
                  <div>
                    <p><strong>Delivery Address:</strong></p>
                    <p style={{ maxWidth: "300px" }}>{order.address}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
