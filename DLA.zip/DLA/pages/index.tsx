
import React from "react";
import Navbar from "../components/Navbar";
import ProductCard from "../components/ProductCard";

const productList = [
  {
    name: "Poco F5",
    brand: "Xiaomi",
    priceINR: 29999,
    priceOre: 299.99,
    image: "https://m.media-amazon.com/images/I/71hEzQGOBoL._SX679_.jpg",
    description: "6.67-inch AMOLED display, 200MP OIS Camera, 120W Fast Charging, 5000mAh battery, Snapdragon 8+ Gen 1"
  },
  {
    name: "iPhone 14 Pro",
    brand: "Apple",
    priceINR: 119999,
    priceOre: 1199.99,
    image: "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-14-pro-model-unselect-gallery-2-202209_GEO_EMEA?wid=5120&hei=2880&fmt=p-jpg&qlt=80&.v=1660753617539",
    description: "6.1-inch Super Retina XDR display, 48MP Camera, A16 Bionic chip, Always-On display, Dynamic Island"
  },
  {
    name: "Galaxy S23 Ultra",
    brand: "Samsung",
    priceINR: 124999,
    priceOre: 1249.99,
    image: "https://images.samsung.com/is/image/samsung/p6pim/in/2302/gallery/in-galaxy-s23-ultra-s918-sm-s918bzkcins-534859377?$650_519_PNG$",
    description: "6.8-inch Dynamic AMOLED 2X display, 200MP Camera, S Pen support, 5000mAh battery, Snapdragon 8 Gen 2"
  },
  {
    name: "Pixel 7 Pro",
    brand: "Google",
    priceINR: 84999,
    priceOre: 849.99,
    image: "https://lh3.googleusercontent.com/spp/AE_ITi1DPrbly0uCt2-Oj26YD_0KJN6XEj5L-UJdgeYrKMbDbRQpg6jliGY4rQH8QZwOZAh47dg-YniuL1NXPNpgxJE9kLJzRXVkZ3TFiXfgU0vfYJT6fEh1xLpnCCXfLKRQKUHpIMqRZHSA0LvIJ2BcF6EGfXGYS1g9k_F4vq2dLVWs_HvapQ54vjWW=w2560-h1297",
    description: "6.7-inch QHD+ LTPO OLED display, 50MP Camera, Google Tensor G2 chip, 5000mAh battery, Advanced AI features"
  }
];

export default function Home() {
  return (
    <div>
      <Navbar />
      <div style={{ padding: "20px", maxWidth: "1200px", margin: "0 auto" }}>
        <div style={{ marginBottom: "40px", textAlign: "center" }}>
          <h1 style={{ fontSize: "2.5rem", marginBottom: "15px" }}>Welcome to DLA - Smartphones Store</h1>
          <p style={{ fontSize: "1.2rem", color: "#666" }}>
            Find the latest smartphones at competitive prices. All prices are displayed in Ores (1 Ore = 100 INR).
          </p>
        </div>
        
        <div style={{ 
          display: "grid", 
          gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", 
          gap: "30px", 
          justifyContent: "center" 
        }}>
          {productList.map((product, index) => (
            <ProductCard key={index} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}
