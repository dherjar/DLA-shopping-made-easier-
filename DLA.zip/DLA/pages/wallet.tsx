
import React, { useState } from "react";
import { useRouter } from "next/router";
import Navbar from "../components/Navbar";
import { useWallet } from "../context/WalletContext";
import { useAuth, Bank } from "../context/AuthContext";

export default function Wallet() {
  const { balance, withdraw, deposit, validateBankPassword } = useWallet();
  const { user } = useAuth();
  const router = useRouter();
  const [amount, setAmount] = useState<number>(0);
  const [selectedBank, setSelectedBank] = useState<string>("");
  const [bankPassword, setBankPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  
  React.useEffect(() => {
    if (!user) {
      router.push("/login");
    }
  }, [user, router]);
  
  if (!user) {
    return <div>Redirecting to login...</div>;
  }

  const handleWithdraw = () => {
    setError("");
    setSuccess("");
    
    if (amount <= 0) {
      setError("Please enter a valid amount!");
      return;
    }
    
    if (!selectedBank) {
      setError("Please select a bank account!");
      return;
    }
    
    if (!bankPassword) {
      setError("Please enter your bank password!");
      return;
    }
    
    const bank = user.banks.find(b => b.cardNumber === selectedBank);
    
    if (!bank) {
      setError("Bank not found!");
      return;
    }
    
    if (!validateBankPassword(bank, bankPassword)) {
      setError("Invalid bank password!");
      return;
    }
    
    if (amount > bank.balance) {
      setError("Insufficient funds in selected bank!");
      return;
    }
    
    const success = withdraw(amount, bank);
    
    if (success) {
      setSuccess(`Withdrawn ${amount.toFixed(2)} Ores from ${bank.name}!`);
      setAmount(0);
      setBankPassword("");
    } else {
      setError("Failed to withdraw. Please try again.");
    }
  };

  const handleDeposit = () => {
    setError("");
    setSuccess("");
    
    if (amount <= 0) {
      setError("Please enter a valid amount!");
      return;
    }
    
    if (amount > balance) {
      setError("Insufficient wallet balance!");
      return;
    }
    
    if (!selectedBank) {
      setError("Please select a bank account!");
      return;
    }
    
    deposit(amount);
    setSuccess(`Deposited ${amount.toFixed(2)} Ores to your wallet!`);
    setAmount(0);
  };

  return (
    <div>
      <Navbar />
      <div style={{ padding: "0 20px", maxWidth: "600px", margin: "0 auto" }}>
        <h1>Your Wallet</h1>
        <div style={{ border: "1px solid #ddd", borderRadius: "8px", padding: "20px", marginBottom: "20px" }}>
          <h2>Balance: {balance.toFixed(2)} Ores</h2>
        </div>
        
        {error && (
          <div style={{ 
            padding: "10px", 
            backgroundColor: "#FFEBEE", 
            color: "#D32F2F", 
            borderRadius: "4px", 
            marginBottom: "20px" 
          }}>
            {error}
          </div>
        )}
        
        {success && (
          <div style={{ 
            padding: "10px", 
            backgroundColor: "#E8F5E9", 
            color: "#388E3C", 
            borderRadius: "4px", 
            marginBottom: "20px" 
          }}>
            {success}
          </div>
        )}
        
        <div style={{ marginBottom: "20px" }}>
          <label style={{ display: "block", marginBottom: "5px" }}>Select Bank Account</label>
          <select 
            value={selectedBank} 
            onChange={(e) => setSelectedBank(e.target.value)}
            style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
          >
            <option value="">Select a bank</option>
            {user.banks.map(bank => (
              <option key={bank.cardNumber} value={bank.cardNumber}>
                {bank.name} - {bank.cardNumber} (Balance: {bank.balance.toFixed(2)} Ores)
              </option>
            ))}
          </select>
        </div>
        
        {selectedBank && (
          <div style={{ marginBottom: "20px" }}>
            <label style={{ display: "block", marginBottom: "5px" }}>Bank Password (for withdrawals)</label>
            <input
              type="password"
              value={bankPassword}
              onChange={(e) => setBankPassword(e.target.value)}
              style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
            />
          </div>
        )}
        
        <div style={{ marginBottom: "20px" }}>
          <label style={{ display: "block", marginBottom: "5px" }}>Amount (Ores)</label>
          <input 
            type="number" 
            placeholder="Enter Amount" 
            value={amount || ""} 
            onChange={(e) => setAmount(Number(e.target.value))} 
            style={{ width: "100%", padding: "10px", borderRadius: "4px", border: "1px solid #ddd" }}
          />
        </div>
        
        <div style={{ display: "flex", gap: "10px", marginTop: "20px" }}>
          <button 
            onClick={handleDeposit}
            style={{ 
              flex: 1,
              padding: "10px 20px", 
              backgroundColor: "#4CAF50", 
              color: "white", 
              border: "none", 
              borderRadius: "5px", 
              cursor: "pointer" 
            }}
          >
            Deposit to Wallet
          </button>
          <button 
            onClick={handleWithdraw}
            style={{ 
              flex: 1,
              padding: "10px 20px", 
              backgroundColor: "#f44336", 
              color: "white", 
              border: "none", 
              borderRadius: "5px", 
              cursor: "pointer" 
            }}
          >
            Withdraw from Bank
          </button>
        </div>
        
        {user.banks.length === 0 && (
          <div style={{ marginTop: "20px", textAlign: "center" }}>
            <p>You don't have any bank accounts yet.</p>
            <button
              onClick={() => router.push("/account")}
              style={{ 
                padding: "10px 15px", 
                backgroundColor: "#2196F3", 
                color: "white", 
                border: "none", 
                borderRadius: "4px", 
                cursor: "pointer",
                marginTop: "10px"
              }}
            >
              Add a Bank Account
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
