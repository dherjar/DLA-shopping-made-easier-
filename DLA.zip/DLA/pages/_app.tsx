
import React from "react";
import { AppProps } from "next/app";
import { AuthProvider } from "../context/AuthContext";
import { CartProvider } from "../context/CartContext";
import { WalletProvider } from "../context/WalletContext";
import { OrderProvider } from "../context/OrderContext";

export default function MyApp({ Component, pageProps }: AppProps) {
  return (
    <AuthProvider>
      <OrderProvider>
        <WalletProvider>
          <CartProvider>
            <Component {...pageProps} />
          </CartProvider>
        </WalletProvider>
      </OrderProvider>
    </AuthProvider>
  );
}
