
import React, { useState, useEffect } from "react";
import { useRouter } from "next/router";
import Navbar from "../components/Navbar";
import { useAuth } from "../context/AuthContext";
import { useOrders } from "../context/OrderContext";

// Get all user keys from users object
const getUsersForAdmin = () => {
  const savedUsers = localStorage.getItem('users');
  const users = savedUsers ? JSON.parse(savedUsers) : {};
  return Object.keys(users).map(username => ({
    username,
    isAdmin: users[username].isAdmin,
    banks: users[username].banks || []
  }));
};

export default function Admin() {
  const { user, adminUpdateBalance } = useAuth();
  const { orders, updateOrderStatus } = useOrders();
  const router = useRouter();
  
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState("");
  const [selectedBank, setSelectedBank] = useState("");
  const [amount, setAmount] = useState<number>(0);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  useEffect(() => {
    if (!user?.isAdmin) {
      router.push("/");
      return;
    }
    
    setAllUsers(getUsersForAdmin());
  }, [user, router, refreshTrigger]);

  const handleUpdateBalance = () => {
    if (!selectedUser || !selectedBank || !amount) {
      alert("Please fill all fields");
      return;
    }
    
    adminUpdateBalance(selectedUser, selectedBank, amount);
    
    alert(`Updated balance for ${selectedUser}'s bank ${selectedBank} by ${amount} Ores`);
    
    setSelectedUser("");
    setSelectedBank("");
    setAmount(0);
    setRefreshTrigger(prev => prev + 1);
  };
  
  const handleStatusChange = (orderId: string, status: string) => {
    updateOrderStatus(orderId, status as any);
    alert(`Order status updated to ${status}`);
  };

  if (!user?.isAdmin) {
    return <div>Redirecting...</div>;
  }

  return (
    <div>
      <Navbar />
      <div style={{ padding: "0 20px", maxWidth: "1000px", margin: "0 auto" }}>
        <h1>Admin Panel</h1>
        
        <div style={{ marginBottom: "40px" }}>
          <h2>Manage User Balances</h2>
          <div style={{ display: "flex", gap: "15px", marginBottom: "20px" }}>
            <div style={{ flex: 1 }}>
              <label style={{ display: "block", marginBottom: "5px" }}>Select User</label>
              <select 
                value={selectedUser} 
                onChange={(e) => {
                  setSelectedUser(e.target.value);
                  setSelectedBank("");
                }}
                style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
              >
                <option value="">Select a user</option>
                {allUsers.map(u => (
                  <option key={u.username} value={u.username}>
                    {u.username} {u.isAdmin ? "(Admin)" : ""}
                  </option>
                ))}
              </select>
            </div>
            
            {selectedUser && (
              <div style={{ flex: 1 }}>
                <label style={{ display: "block", marginBottom: "5px" }}>Select Bank</label>
                <select 
                  value={selectedBank} 
                  onChange={(e) => setSelectedBank(e.target.value)}
                  style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
                >
                  <option value="">Select a bank</option>
                  {allUsers
                    .find(u => u.username === selectedUser)?.banks
                    .map((bank: any) => (
                      <option key={bank.cardNumber} value={bank.cardNumber}>
                        {bank.name} - {bank.cardNumber} (Balance: {bank.balance} Ores)
                      </option>
                    ))}
                </select>
              </div>
            )}
            
            {selectedBank && (
              <div style={{ flex: 1 }}>
                <label style={{ display: "block", marginBottom: "5px" }}>Amount (Ores)</label>
                <input
                  type="number"
                  value={amount || ""}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
                />
                <p style={{ fontSize: "12px", color: "#888", marginTop: "5px" }}>
                  Use negative values to deduct balance
                </p>
              </div>
            )}
          </div>
          
          {selectedBank && (
            <button
              onClick={handleUpdateBalance}
              style={{ 
                padding: "10px 15px", 
                backgroundColor: "#4CAF50", 
                color: "white", 
                border: "none", 
                borderRadius: "4px", 
                cursor: "pointer"
              }}
            >
              Update Balance
            </button>
          )}
        </div>
        
        <div>
          <h2>Manage Orders</h2>
          {orders.length === 0 ? (
            <p>No orders yet.</p>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th style={{ border: "1px solid #ddd", padding: "10px", textAlign: "left" }}>Order ID</th>
                  <th style={{ border: "1px solid #ddd", padding: "10px", textAlign: "left" }}>User</th>
                  <th style={{ border: "1px solid #ddd", padding: "10px", textAlign: "left" }}>Date</th>
                  <th style={{ border: "1px solid #ddd", padding: "10px", textAlign: "left" }}>Total</th>
                  <th style={{ border: "1px solid #ddd", padding: "10px", textAlign: "left" }}>Payment</th>
                  <th style={{ border: "1px solid #ddd", padding: "10px", textAlign: "left" }}>Status</th>
                  <th style={{ border: "1px solid #ddd", padding: "10px", textAlign: "left" }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(order => (
                  <tr key={order.id}>
                    <td style={{ border: "1px solid #ddd", padding: "10px" }}>{order.id}</td>
                    <td style={{ border: "1px solid #ddd", padding: "10px" }}>{order.userId}</td>
                    <td style={{ border: "1px solid #ddd", padding: "10px" }}>
                      {new Date(order.date).toLocaleString()}
                    </td>
                    <td style={{ border: "1px solid #ddd", padding: "10px" }}>
                      {order.totalAmount.toFixed(2)} Ores
                    </td>
                    <td style={{ border: "1px solid #ddd", padding: "10px" }}>
                      {order.paymentMethod === "ewallet" ? "E-Wallet" : "Cash on Delivery"}
                    </td>
                    <td style={{ border: "1px solid #ddd", padding: "10px" }}>
                      <span style={{ 
                        padding: "3px 8px", 
                        borderRadius: "4px", 
                        backgroundColor: 
                          order.status === "pending" ? "#FFC107" :
                          order.status === "processing" ? "#2196F3" :
                          order.status === "shipped" ? "#9C27B0" :
                          order.status === "delivered" ? "#4CAF50" :
                          "#F44336",
                        color: "white",
                        fontSize: "12px",
                        fontWeight: "bold"
                      }}>
                        {order.status.toUpperCase()}
                      </span>
                    </td>
                    <td style={{ border: "1px solid #ddd", padding: "10px" }}>
                      <select
                        value={order.status}
                        onChange={(e) => handleStatusChange(order.id, e.target.value)}
                        style={{ padding: "5px", borderRadius: "4px", border: "1px solid #ddd" }}
                      >
                        <option value="pending">Pending</option>
                        <option value="processing">Processing</option>
                        <option value="shipped">Shipped</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
