
import React, { useState } from "react";
import { useRouter } from "next/router";
import Navbar from "../components/Navbar";
import { useAuth, Bank } from "../context/AuthContext";

export default function Account() {
  const { user, addBank, removeBank } = useAuth();
  const router = useRouter();
  
  const [showAddBank, setShowAddBank] = useState(false);
  const [newBank, setNewBank] = useState<Omit<Bank, "balance">>({
    name: "",
    cardNumber: "",
    password: ""
  });
  
  React.useEffect(() => {
    if (!user) {
      router.push("/login");
    }
  }, [user, router]);
  
  if (!user) {
    return <div>Redirecting to login...</div>;
  }
  
  const handleAddBank = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newBank.name || !newBank.cardNumber || !newBank.password) {
      alert("Please fill all fields");
      return;
    }
    
    addBank({
      ...newBank,
      balance: 5000 // Starting balance of 5000 ores
    });
    
    setNewBank({
      name: "",
      cardNumber: "",
      password: ""
    });
    
    setShowAddBank(false);
  };
  
  return (
    <div>
      <Navbar />
      <div style={{ padding: "0 20px", maxWidth: "800px", margin: "0 auto" }}>
        <h1>Account</h1>
        
        <div style={{ marginBottom: "30px" }}>
          <h2>Your Bank Accounts</h2>
          {user.banks.length === 0 ? (
            <p>You have no bank accounts yet.</p>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "20px" }}>
              {user.banks.map((bank) => (
                <div key={bank.cardNumber} style={{ 
                  border: "1px solid #ddd", 
                  borderRadius: "8px", 
                  padding: "15px",
                  boxShadow: "0 2px 4px rgba(0,0,0,0.1)"
                }}>
                  <h3>{bank.name}</h3>
                  <p>Card Number: {bank.cardNumber}</p>
                  <p>Balance: {bank.balance.toFixed(2)} Ores</p>
                  <button
                    onClick={() => removeBank(bank.cardNumber)}
                    style={{ 
                      padding: "8px 15px", 
                      backgroundColor: "#f44336", 
                      color: "white", 
                      border: "none", 
                      borderRadius: "4px", 
                      cursor: "pointer",
                      marginTop: "10px"  
                    }}
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          )}
          
          {!showAddBank ? (
            <button
              onClick={() => setShowAddBank(true)}
              style={{ 
                padding: "10px 15px", 
                backgroundColor: "#4CAF50", 
                color: "white", 
                border: "none", 
                borderRadius: "4px", 
                cursor: "pointer",
                marginTop: "20px"  
              }}
            >
              Add Bank Account
            </button>
          ) : (
            <div style={{ marginTop: "20px", border: "1px solid #ddd", borderRadius: "8px", padding: "20px" }}>
              <h3>Add New Bank Account</h3>
              <form onSubmit={handleAddBank}>
                <div style={{ marginBottom: "15px" }}>
                  <label style={{ display: "block", marginBottom: "5px" }}>Bank Name</label>
                  <input
                    type="text"
                    value={newBank.name}
                    onChange={(e) => setNewBank({ ...newBank, name: e.target.value })}
                    style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
                  />
                </div>
                <div style={{ marginBottom: "15px" }}>
                  <label style={{ display: "block", marginBottom: "5px" }}>Card Number</label>
                  <input
                    type="text"
                    value={newBank.cardNumber}
                    onChange={(e) => setNewBank({ ...newBank, cardNumber: e.target.value })}
                    style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
                  />
                </div>
                <div style={{ marginBottom: "15px" }}>
                  <label style={{ display: "block", marginBottom: "5px" }}>Password</label>
                  <input
                    type="password"
                    value={newBank.password}
                    onChange={(e) => setNewBank({ ...newBank, password: e.target.value })}
                    style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
                  />
                </div>
                <div style={{ display: "flex", gap: "10px" }}>
                  <button
                    type="submit"
                    style={{ 
                      padding: "10px 15px", 
                      backgroundColor: "#4CAF50", 
                      color: "white", 
                      border: "none", 
                      borderRadius: "4px", 
                      cursor: "pointer" 
                    }}
                  >
                    Add Bank
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowAddBank(false)}
                    style={{ 
                      padding: "10px 15px", 
                      backgroundColor: "#f44336", 
                      color: "white", 
                      border: "none", 
                      borderRadius: "4px", 
                      cursor: "pointer" 
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
