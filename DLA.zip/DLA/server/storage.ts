import { 
  users, type User, type InsertUser,
  bankAccounts, type BankAccount, type InsertBankAccount,
  orders, type Order, type InsertOrder,
  orderItems, type OrderItem, type InsertOrderItem
} from "@shared/schema";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLoginStatus(id: number, isLoggedIn: boolean): Promise<void>;
  updateUserPin(id: number, pin: string): Promise<void>;

  // Bank account management
  createBankAccount(account: InsertBankAccount): Promise<BankAccount>;
  getBankAccounts(userId: number): Promise<BankAccount[]>;
  getBankAccount(id: number): Promise<BankAccount | undefined>;
  updateBankBalance(id: number, newBalance: number): Promise<void>;
  deleteBankAccount(id: number): Promise<void>;

  // Order management
  createOrder(order: InsertOrder): Promise<Order>;
  getOrder(id: number): Promise<Order | undefined>;
  getUserOrders(userId: number): Promise<Order[]>;
  updateOrderStatus(id: number, status: string): Promise<void>;

  // Order items
  createOrderItem(item: InsertOrderItem): Promise<OrderItem>;
  getOrderItems(orderId: number): Promise<OrderItem[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private bankAccounts: Map<number, BankAccount>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private currentId: { [key: string]: number };

  constructor() {
    this.users = new Map();
    this.bankAccounts = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.currentId = {
      users: 1,
      bankAccounts: 1,
      orders: 1,
      orderItems: 1
    };

    // Create default admin and user accounts
    this.createUser({
      username: "dheeraj123",
      password: "d1234kumar",
      role: "admin",
      pin: null
    });

    this.createUser({
      username: "shagun123",
      password: "s1234kumar",
      role: "user",
      pin: null
    });
  }

  // User management methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const user: User = { ...insertUser, id, isLoggedIn: false };
    this.users.set(id, user);
    return user;
  }

  async updateUserLoginStatus(id: number, isLoggedIn: boolean): Promise<void> {
    const user = await this.getUser(id);
    if (user) {
      this.users.set(id, { ...user, isLoggedIn });
    }
  }

  async updateUserPin(id: number, pin: string): Promise<void> {
    const user = await this.getUser(id);
    if (user) {
      this.users.set(id, { ...user, pin });
    }
  }

  // Bank account management methods
  async createBankAccount(insertAccount: InsertBankAccount): Promise<BankAccount> {
    const id = this.currentId.bankAccounts++;
    const account: BankAccount = { ...insertAccount, id, isActive: true };
    this.bankAccounts.set(id, account);
    return account;
  }

  async getBankAccounts(userId: number): Promise<BankAccount[]> {
    return Array.from(this.bankAccounts.values()).filter(
      (account) => account.userId === userId && account.isActive
    );
  }

  async getBankAccount(id: number): Promise<BankAccount | undefined> {
    return this.bankAccounts.get(id);
  }

  async updateBankBalance(id: number, newBalance: number): Promise<void> {
    const account = await this.getBankAccount(id);
    if (account) {
      this.bankAccounts.set(id, { ...account, balance: newBalance });
    }
  }

  async deleteBankAccount(id: number): Promise<void> {
    const account = await this.getBankAccount(id);
    if (account) {
      this.bankAccounts.set(id, { ...account, isActive: false });
    }
  }

  // Order management methods
  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.currentId.orders++;
    const order: Order = { 
      ...insertOrder,
      id,
      status: "pending",
      createdAt: new Date()
    };
    this.orders.set(id, order);
    return order;
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getUserOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.userId === userId
    );
  }

  async updateOrderStatus(id: number, status: string): Promise<void> {
    const order = await this.getOrder(id);
    if (order) {
      this.orders.set(id, { ...order, status });
    }
  }

  // Order items methods
  async createOrderItem(insertItem: InsertOrderItem): Promise<OrderItem> {
    const id = this.currentId.orderItems++;
    const item: OrderItem = { ...insertItem, id };
    this.orderItems.set(id, item);
    return item;
  }

  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values()).filter(
      (item) => item.orderId === orderId
    );
  }
}

export const storage = new MemStorage();