import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema,
  insertBankAccountSchema,
  insertOrderSchema,
  insertOrderItemSchema
} from "@shared/schema";
import { z } from "zod";

// Custom middleware to check if user is logged in
const requireAuth = async (req: Request, res: Response, next: Function) => {
  const userId = req.session?.userId;
  if (!userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const user = await storage.getUser(userId);
  if (!user || !user.isLoggedIn) {
    return res.status(401).json({ message: "Please log in" });
  }

  next();
};

// Custom middleware to check if user is admin
const requireAdmin = async (req: Request, res: Response, next: Function) => {
  const userId = req.session?.userId;
  if (!userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const user = await storage.getUser(userId);
  if (!user || user.role !== "admin") {
    return res.status(403).json({ message: "Admin access required" });
  }

  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Add this new route at the beginning of registerRoutes function
  app.get("/api/auth/me", async (req, res) => {
    const userId = req.session?.userId;
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const user = await storage.getUser(userId);
    if (!user || !user.isLoggedIn) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Don't send the password back to the client
    const { password, ...safeUser } = user;
    res.json(safeUser);
  });

  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    const { username, password } = req.body;
    const user = await storage.getUserByUsername(username);

    if (!user || user.password !== password) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    await storage.updateUserLoginStatus(user.id, true);
    req.session.userId = user.id;
    res.json({ user: { ...user, password: undefined } });
  });

  app.post("/api/auth/logout", requireAuth, async (req, res) => {
    if (req.session?.userId) {
      await storage.updateUserLoginStatus(req.session.userId, false);
      req.session.destroy(() => {
        res.json({ message: "Logged out successfully" });
      });
    }
  });

  app.post("/api/users/pin", requireAuth, async (req, res) => {
    const { pin } = req.body;
    if (!pin || typeof pin !== "string" || pin.length !== 4) {
      return res.status(400).json({ message: "Invalid PIN format" });
    }

    await storage.updateUserPin(req.session.userId!, pin);
    res.json({ message: "PIN updated successfully" });
  });

  // Bank account routes
  app.post("/api/bank-accounts", requireAuth, async (req, res) => {
    try {
      const bankAccount = insertBankAccountSchema.parse({
        ...req.body,
        userId: req.session.userId
      });
      const created = await storage.createBankAccount(bankAccount);
      res.json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid bank account data" });
      }
      throw error;
    }
  });

  app.get("/api/bank-accounts", requireAuth, async (req, res) => {
    const accounts = await storage.getBankAccounts(req.session.userId!);
    res.json(accounts);
  });

  app.delete("/api/bank-accounts/:id", requireAuth, async (req, res) => {
    const accountId = parseInt(req.params.id);
    const account = await storage.getBankAccount(accountId);

    if (!account || account.userId !== req.session.userId) {
      return res.status(404).json({ message: "Bank account not found" });
    }

    await storage.deleteBankAccount(accountId);
    res.json({ message: "Bank account deleted successfully" });
  });

  // Order routes
  app.post("/api/orders", requireAuth, async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse({
        ...req.body,
        userId: req.session.userId
      });

      // If payment mode is wallet, verify bank account and balance
      if (orderData.paymentMode === "wallet") {
        const bankAccount = await storage.getBankAccount(orderData.bankAccountId!);
        if (!bankAccount || bankAccount.userId !== req.session.userId) {
          return res.status(400).json({ message: "Invalid bank account" });
        }

        if (parseFloat(bankAccount.balance.toString()) < parseFloat(orderData.totalAmount.toString())) {
          return res.status(400).json({ message: "Insufficient balance" });
        }

        // Deduct balance
        await storage.updateBankBalance(
          bankAccount.id,
          parseFloat(bankAccount.balance.toString()) - parseFloat(orderData.totalAmount.toString())
        );
      }

      const order = await storage.createOrder(orderData);

      // Create order items
      const items = req.body.items || [];
      for (const item of items) {
        await storage.createOrderItem({
          orderId: order.id,
          ...item
        });
      }

      res.json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data" });
      }
      throw error;
    }
  });

  app.get("/api/orders", requireAuth, async (req, res) => {
    const orders = await storage.getUserOrders(req.session.userId!);
    res.json(orders);
  });

  app.get("/api/orders/:id", requireAuth, async (req, res) => {
    const orderId = parseInt(req.params.id);
    const order = await storage.getOrder(orderId);

    if (!order || (order.userId !== req.session.userId)) {
      return res.status(404).json({ message: "Order not found" });
    }

    const items = await storage.getOrderItems(orderId);
    res.json({ ...order, items });
  });

  // Admin routes
  app.get("/api/admin/orders", requireAdmin, async (req, res) => {
    const orders = Array.from((await Promise.all(
      Array.from({ length: storage.currentId.orders - 1 }, (_, i) => i + 1)
        .map(id => storage.getOrder(id))
    )).filter(Boolean));
    res.json(orders);
  });

  app.patch("/api/admin/orders/:id/status", requireAdmin, async (req, res) => {
    const orderId = parseInt(req.params.id);
    const { status } = req.body;

    if (!["pending", "processing", "shipped", "delivered"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    const order = await storage.getOrder(orderId);
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    await storage.updateOrderStatus(orderId, status);
    res.json({ message: "Order status updated successfully" });
  });

  app.patch("/api/admin/bank-accounts/:id/balance", requireAdmin, async (req, res) => {
    const accountId = parseInt(req.params.id);
    const { balance } = req.body;

    if (typeof balance !== "number" || balance < 0) {
      return res.status(400).json({ message: "Invalid balance" });
    }

    const account = await storage.getBankAccount(accountId);
    if (!account) {
      return res.status(404).json({ message: "Bank account not found" });
    }

    await storage.updateBankBalance(accountId, balance);
    res.json({ message: "Bank account balance updated successfully" });
  });

  const httpServer = createServer(app);
  return httpServer;
}